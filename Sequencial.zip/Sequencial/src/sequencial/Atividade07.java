package sequencial;

import java.util.*;

public class Atividade07 {

	public static void main(String[]args) {
		Scanner scanner = new Scanner (System.in);
		
		double a = scanner.nextDouble();
		System.out.println("A área é: "+ (a*a));
		
	}
	
}
