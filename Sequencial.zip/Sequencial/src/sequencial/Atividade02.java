package sequencial;

import java.util.*;

public class Atividade02 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner (System.in);
		
		int numero = scanner.nextInt();
		
		System.out.print("O número informado foi: " + numero);
		
	}

}
