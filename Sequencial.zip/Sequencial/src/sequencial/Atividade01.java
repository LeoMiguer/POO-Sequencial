package sequencial;

import java.util.*;

public class Atividade01 {

	public static void main(String[] args) {
	System.out.println("Alo Mundo");
	}
	
}
